# firebasedemofordatabase
storing data into firebase database and access data from firebase database  in ios 
